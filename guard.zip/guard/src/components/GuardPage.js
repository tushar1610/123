import React from 'react'
import Visitors from './Visitors'

export default function GuardPage() {
  return (
    <div>
        <Visitors title="guardUser"/>
    </div>
  ) 
}